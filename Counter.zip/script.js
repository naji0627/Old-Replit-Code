//this is single line comment in JavaScript

/*this is a 
multi-line
comment in JavaScript*/

var temp = 60;

console.log("What outerwear do I need?")
console.log("I need...");

/* if (temp > 70) {
  console.log("No jacket");
} else if (temp < 40) {
  console.log("THE HEAVIEST OF JACKETS");
} else {
  console.log("A light Jacket"); 
} */

var numOne = 5

var numTwo = 9

if (numOne + numTwo === 14) {
  console.log(numOne + numTwo)
} else {
  console.log(false)
};

var clickCount = 0;
var countButton = document.getElementById("countButton");
var countDisplay = document.getElementById("countDisplay");

countButton.addEventListener("click", increaseCounter);

function increaseCounter(){
 // clickCount = clickCount + 1;
  clickCount++;
console.log(clickCount);
  countDisplay.innerHTML = clickCount;
}

