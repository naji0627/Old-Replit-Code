function submit() {

  let lname = document.getElementById("lname");

  let fname = document.getElementById("fname");

  let age = document.getElementById("age");



// || equals or in javascript

  if(fname.value === "Aidan" && lname.value === "Blot" && age.value === "15") {
    console.log(fname.value, lname.value, age.value);
    window.location.replace("Aidan.html");
    } 
    else if(fname.value === "Naji" || "naji" && lname.value === "Genas" || "genas" && age.value === "14") {
      console.log(fname.value, lname.value, age.value);
      window.location.replace("coder.html");
    } 
    else if (fname.value === "Du-Wayne" && lname.value === "Genas" && age.value === "30" ) {
      console.log(fname.value, lname.value, age.value);
      window.location.replace("Cuz.html");
    } 
    else {
      console.log(fname.value, lname.value, age.value);
      window.location.replace("NotAidan.html");
    }

}