<?php
    echo "Logout Successful";
    session_destroy();   // function that Destroys Session 
    header("Location: index.php");
?>