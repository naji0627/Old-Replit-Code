<?php
  if (session_status() == PHP_SESSION_NONE) 
  {
      session_start();
      if (!isset($_SESSION['username'])) 
      {
        $_SESSION['username'] = $username;
      }
  }

?>
<html>
  <head>
    <title>Action_page</title>
  </head>
  <body>
  
<?php
    // If session is not set then redirect to Login Page
    if(!isset($_SESSION['username'])) {
        header("Location:index.php");  
    } else {

        echo sprintf('Hello %s',$_SESSION['username']);
        echo "\n"."<a href='logout.php'> Logout</a> "; 
    }
?>
  </body>
</html>