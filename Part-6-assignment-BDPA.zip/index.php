<?php
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
            }

            $fnameErr = $lnameErr = $emailErr = $passwordErr = $usernameErr = $zipErr = $cityErr = $addressErr = $phoneErr = $statesErr = "";

            $fname = $lname = $email = $phone = $username = $password = $address = $city = $zip = $states = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $fname = test_input($_POST["firstname"]);
            $lname = test_input($_POST["lastname"]);
            $email = test_input($_POST["email"]);
            $phone = test_input($_POST["phone"]);
            $username = test_input($_POST["username"]);
            $password = test_input($_POST["password"]);
            $address = test_input($_POST["address"]);
            $city = test_input($_POST["city"]);
            $zip = test_input($_POST["zip"]);
            $states = test_input($_POST["state"]);
         }
// || stands for or, and && stands for and

         
        if (!preg_match("/^[a-zA-Z]*'$/", $fname)) {
           echo 'Invalid name given';
        } 
    


        if (!preg_match("/^[a-zA-Z]'*$/", $lname)) {
            $lnameErr = "Invalid name given";
        } 

        if (empty($_POST ["address"])) {
          $addressErr = "Address is required";
        } else {
          $address = test_input($_POST["address"]);
        }

        if (empty($_POST ["email"])) {
          $emailErr = "State is required";
        } else {
          $email = test_input($_POST["state"]);
        }

        if (empty($_POST ["phone"])) {
          $phoneErr = "State is required";
        } else {
          $phone = test_input($_POST["state"]);
        }

        if (empty($_POST ["state"])) {
          $statesErr = "State is required";
        } else {
          $states = test_input($_POST["state"]);
        }

        if (empty($_POST ["zip"])) {
          $zipErr = "Zip is required";
        } else {
          $zip = test_input($_POST["zip"]);
        }

        if (empty($_POST ["username"])) {
          $usersameErr = "Username is required";
        } else {
          $username = test_input($_POST["username"]);
        }

        if (empty($_POST ["password"])) {
          $passwordErr = "Password is required";
        } else {
          $password = test_input($_POST["password"]);
        }


        if (!filter_var("email", FILTER_VALIDATE_EMAIL)) {
             $emailErr = "* Invalid email format";
           }

         





function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
}
  ?>

<html>
  <head>
    <title>Multi Step Registration Form</title>
    <style>/* Style the form */
    #regForm {
      background-color: salmon;
      margin: 100px auto;
      padding: 40px;
      width: 70%;
      min-width: 300px;
    }

    /* Style the input fields */
    input {
      padding: 10px;
      width: 100%;
      font-size: 17px;
      font-family: Raleway;
      border: 1px solid #aaaaaa;
    }

    /* Mark input boxes that gets an error on validation: */
    input.invalid {
      background-color: #ffdddd;
    }

    body {
      background-color: lightblue
    }

    /* Hide all steps by default: */
    .tab {
      display: none;
    }

    /* Make circles that indicate the steps of the form: */
    .step {
      height: 15px;
      width: 15px;
      margin: 0 2px;
      background-color: #bbbbbb;
      border: none;
      border-radius: 50%;
      display: inline-block;
      opacity: 0.5;
    }

    /* Mark the active step: */
    .step.active {
      opacity: 1;
    }

    /* Mark the steps that are finished and valid: */
    .step.finish {
      background-color: #04AA6D;
    }

    button {
      background-color: lightblue;
      color: darkblue;
      border: 2px solid lightblue;
padding: 10px 25px;
border-radius: 6px;
    }

    button:hover {
      background-color: darkblue;
      color: lightblue;
    }

    </style>
  </head>
  <body>




    <form id="regForm" method="post" action="post">
    <h1>Register</h1>
      <div class="tab">Name:
        <p><input placeholder="First Name" oninput="this.className = ''" name="fname"><span class="error"> </span></p>
        <p><input placeholder="Last name" oninput="this.className = ''" name="lname"><span class="error"> </span></p>
      </div>
      <div class="tab">Contact Info:
        <p><input type="email" placeholder="E-mail" oninput="this.className = ''" name="email"><span class="error"> </span></p>
        <p><input type="tel" placeholder="Phone" oninput="this.className = ''" name="phone"><span class="error"> </span></p>
      </div>
      <div class="tab">Address:
        <p><input placeholder="Address" oninput="this.className = '' name="address"><span class="error"> </span></p>
        <p><input placeholder="City" oninput="this.className = '' name="city"><span class="error"> </span></p>
        <!-- <p><input placeholder="State" oninput="this.className = ''" name="state"></p> -->

        <select name="states" id="states" onselect="this.className" = '' form="regForm">
	<option value="AL">Alabama</option>
	<option value="AK">Alaska</option>
	<option value="AZ">Arizona</option>
	<option value="AR">Arkansas</option>
	<option value="CA">California</option>
	<option value="CO">Colorado</option>
	<option value="CT">Connecticut</option>
	<option value="DE">Delaware</option>
	<option value="DC">District Of Columbia</option>
	<option value="FL">Florida</option>
	<option value="GA">Georgia</option>
	<option value="HI">Hawaii</option>
	<option value="ID">Idaho</option>
	<option value="IL">Illinois</option>
	<option value="IN">Indiana</option>
	<option value="IA">Iowa</option>
	<option value="KS">Kansas</option>
	<option value="KY">Kentucky</option>
	<option value="LA">Louisiana</option>
	<option value="ME">Maine</option>
	<option value="MD">Maryland</option>
	<option value="MA">Massachusetts</option>
	<option value="MI">Michigan</option>
	<option value="MN">Minnesota</option>
	<option value="MS">Mississippi</option>
	<option value="MO">Missouri</option>
	<option value="MT">Montana</option>
	<option value="NE">Nebraska</option>
	<option value="NV">Nevada</option>
	<option value="NH">New Hampshire</option>
	<option value="NJ">New Jersey</option>
	<option value="NM">New Mexico</option>
	<option value="NY">New York</option>
	<option value="NC">North Carolina</option>
	<option value="ND">North Dakota</option>
	<option value="OH">Ohio</option>
	<option value="OK">Oklahoma</option>
	<option value="OR">Oregon</option>
	<option value="PA">Pennsylvania</option>
	<option value="RI">Rhode Island</option>
	<option value="SC">South Carolina</option>
	<option value="SD">South Dakota</option>
	<option value="TN">Tennessee</option>
	<option value="TX">Texas</option>
	<option value="UT">Utah</option>
	<option value="VT">Vermont</option>
	<option value="VA">Virginia</option>
	<option value="WA">Washington</option>
	<option value="WV">West Virginia</option>
	<option value="WI">Wisconsin</option>
	<option value="WY">Wyoming</option>
</select>		


        <p><input placeholder="Zip" oninput="this.className = ''" name="zip"><span class="error"> </span></p>
      </div>
      <div class="tab">Login Info:
        <p><input placeholder="Username" oninput="this.className = ''" name="username"><span class="error"> </span></p>
        <p><input placeholder="Password" oninput="this.className = ''" name="password" type="password"><span class="error"> </span></p>
      </div>
      <div style="overflow:auto;">
        <div style="float:right;">
          <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
          <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
        </div>
      </div>

      <!-- Circles which indicates the steps of the form: -->
      <div style="text-align:center;margin-top:40px;">
        <span class="step"></span>
        <span class="step"></span>
        <span class="step"></span>
        <span class="step"></span>
      </div>
    </form>
    <script>
      var currentTab = 0; // Current tab is set to be the first tab (0)
      showTab(currentTab); // Display the current tab

      function showTab(n) {
      // This function will display the specified tab of the form ...
      var x = document.getElementsByClassName("tab");
      x[n].style.display = "block";
      // ... and fix the Previous/Next buttons:
      if (n == 0) {
        document.getElementById("prevBtn").style.display = "none";
      } else {
        document.getElementById("prevBtn").style.display = "inline";
      }
      if (n == (x.length - 1)) {
        document.getElementById("nextBtn").innerHTML = "Submit";
      } else {
        document.getElementById("nextBtn").innerHTML = "Next";
      }
      // ... and run a function that displays the correct step indicator:
      fixStepIndicator(n)
      }

      function nextPrev(n) {
      // This function will figure out which tab to display
      var x = document.getElementsByClassName("tab");
      // Exit the function if any field in the current tab is invalid:
      if (n == 1 && !validateForm()) return false;
      // Hide the current tab:
      x[currentTab].style.display = "none";
      // Increase or decrease the current tab by 1:
      currentTab = currentTab + n;
      // if you have reached the end of the form... :
      if (currentTab >= x.length) {
        //...the form gets submitted:
        document.getElementById("regForm").submit();
        return false;
      }
      // Otherwise, display the correct tab:
      showTab(currentTab);
      }

      function validateForm() {
      // This function deals with validation of the form fields
      var x, y, i, valid = true;
      x = document.getElementsByClassName("tab");
      y = x[currentTab].getElementsByTagName("input");
      // A loop that checks every input field in the current tab:
      for (i = 0; i < y.length; i++) {
        // If a field is empty...
        if (y[i].value == "") {
          // add an "invalid" class to the field:
          y[i].className += " invalid";
          // and set the current valid status to false:
          valid = false;
        }
      }
      // If the valid status is true, mark the step as finished and valid:
      if (valid) {
        document.getElementsByClassName("step")[currentTab].className += " finish";
      }
      return valid; // return the valid status
      }

      function fixStepIndicator(n) {
      // This function removes the "active" class of all steps...
      var i, x = document.getElementsByClassName("step");
      for (i = 0; i < x.length; i++) {
        x[i].className = x[i].className.replace(" active", "");
      }
      //... and adds the "active" class to the current step:
      x[n].className += " active";
      }
    </script>
  </body>
</html>