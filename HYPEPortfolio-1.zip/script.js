//
/*

*/
greeting = 'Hello! Welcome to my console....Wait...I dont remember giving you access to this. Why are you here.';

console.log (greeting);

