//this is single line comment in JavaScript

/*this is a 
multi-line
comment in JavaScript*/

var quoteList = [
  "You can do anything you put your mind to", "You are loved and worth love", "Your positivity can change your day for the better", "You are BEAUTIFUL!"
];

var quote = document.getElementById("quote");
var qBtn = document.getElementById("qBtn");
var count = 0;

// event listener

qBtn.addEventListener("click", displayQuote);

function displayQuote() {
  quote.innerHTML = quoteList[count];
  count++;
  if (count == quoteList.length) {count = 0;}
}
