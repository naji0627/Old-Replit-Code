function submit() {

  let lname = document.getElementById("lname");

  let year = document.getElementById("year");

  let age = document.getElementById("age");

  if(lname.value === "Leighvard" || "leighvard" && year.value === "2013" && age.value === "9") {
    console.log(lname.value, year.value, age.value);
      window.location.replace("yes2.html");
  } else {console.log(lname.value, year.value, age.value);
      window.location.replace("Liar.html");}

}
