<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php 
    /*Create a simple form with 5 fields
    1. Name
    2. Email
    3. Phone number
    4. Age
    5. Comment

    Make name and email required and the others optional

    Validate email (sanitize) in PHP to esure data is clean
    */



    
    
   ?> 
  </body>
</html>



<html>
   
   <head>
      <title>BDPA form assignment</title>
   </head>
   
   <body>
      <?php
         
         // define variables and set to empty values
         $name = $email = $number = $age = $comment = "";
         
         if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = test_input($_POST["name"]);
            $email = test_input($_POST["email"]);
            $age = test_input($_POST["age"]);
            $comment = test_input($_POST["comment"]);
            $number = test_input($_POST["number"]);
         }
         
function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
         }
          
        
      ?>


      

      
   

      <h2>BDPA Form</h2>
      
      <form method = "post" action = "index.php">
         <table>
            <tr>
               <td>Name:</td> 
               <td><input type = "text" name = "name"></td>
            </tr>
            
            <tr>
               <td>E-mail:</td>
               <td><input type = "text" action = "sanitize.php" name = "email"></td>
            </tr>
            
            <tr>
               <td>Phone Number</td>
               <td><input type="number" name = "number"></td>
            </tr>

            <tr>
               <td>Age</td>
               <td><input type = "number" name = "age"></td>
            </tr>
            
            <tr>
               <td>Comment</td>
               <td><textarea name = "comment" rows = "4" cols = "20"></textarea></td>
            </tr>
            
            
            
            <tr>
               <td>
                  <input type = "submit" name = "submit" value = "Submit"> 
               </td>
            </tr>
         </table>
      </form>
      
      <?php
         echo "<h2> The Given details are :</h2>";
         echo $name;
         echo "<br>";
         
         echo $email;
         echo "<br>";
         
         echo $number;
         echo "<br>";
         
         echo $age;
         echo "<br>";
         
         echo $comment;

      ?>
      
      </body>
   

</html>