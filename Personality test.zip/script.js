consolelog = 'WHY ARE YOU HERE!? Just kinding, welcome to my console! Feel free to do what you please, just dont ruin my code! I worked so hard on it T^T'

console.log (consolelog)

let questionPosition = 0;

let outdoorsScore = 0
let indoorsScore = 0
let artScore = 0
let swimmingScore = 0

let q1a1 = document.getElementById("q1a1");
let q1a2 = document.getElementById("q1a2");
let q1a3 = document.getElementById("q1a3");
let q1a4 = document.getElementById("q1a4");

let q2a1 = document.getElementById("q2a1");
let q2a2 = document.getElementById("q2a2");
let q2a3 = document.getElementById("q2a3");
let q2a4 = document.getElementById("q2a4");

let q3a1 = document.getElementById("q3a1");
let q3a2 = document.getElementById("q3a2");
let q3a3 = document.getElementById("q3a3");
let q3a4 = document.getElementById("q3a4");

let q4a1 = document.getElementById("q4a1");
let q4a2 = document.getElementById("q4a2");
let q4a3 = document.getElementById("q4a3");
let q4a4 = document.getElementById("q4a4");

let q5a1 = document.getElementById("q5a1");
let q5a2 = document.getElementById("q5a2");
let q5a3 = document.getElementById("q5a3");
let q5a4 = document.getElementById("q5a4");

//Question count increses every time you get the same answer
//When question count gets to 4 it means the quiz is overrr!


q1a1.addEventListener("click", outdoors );
q1a2.addEventListener("click", indoors );
q1a3.addEventListener("click", art );
q1a4.addEventListener("click", swimming );

q2a1.addEventListener("click", art );
q2a2.addEventListener("click", indoors );
q2a3.addEventListener("click", outdoors );
q2a4.addEventListener("click", swimming );

q3a1.addEventListener("click", indoors );
q3a2.addEventListener("click", outdoors );
q3a3.addEventListener("click", swimming );
q3a4.addEventListener("click", art );

q4a1.addEventListener("click", outdoors );
q4a2.addEventListener("click", indoors );
q4a3.addEventListener("click", swimming );
q4a4.addEventListener("click", art );

q5a1.addEventListener("click", outdoors );
q5a2.addEventListener("click", indoors );
q5a3.addEventListener("click", art );
q5a4.addEventListener("click", swimming );


function indoors(){
  indoorsScore += 1;
  questionPosition += 1;
  
  if (questionPosition >= 3){
    updateResult();
  }
}

function outdoors(){
  outdoorsScore += 1;
  questionPosition += 1;
  
  if (questionPosition >= 3){
    updateResult();
  }
}


function swimming(){
  swimmingScore += 1;
  questionPosition += 1;
  
  if (questionPosition >= 3){
    updateResult();
  }
}

function art(){
  artScore += 1;
  questionPosition += 1;
  
  if (questionPosition >= 3){
    updateResult();
  }
}

function updateResult(){
  let result = document.getElementById ("result");
  if (indoorsScore >=2){
    result.innerHTML = "Chilling indoors! You prefer to stay in the comfort of you house, instead of being outdoors";
  }
  else if (outdoorsScore >=2){
    result.innerHTML = "Outdoors! You love being outdoors and would rather be out than at home!" ;
  }
   else if (artScore >=2){
    result.innerHTML = "Art! You are very creative (And a person after my own heart)!";
  }
   else if (swimmingScore >=2){
    result.innerHTML = "Swimming! You enjoy going swimming, the water always feels amazing to you."; 
   }
  else {
    result.innerHTML = "Wow you must love a lot of things, we can't pin point your favorite activity!"
  }
  
}


var Restart = document.getElementById("Restart");

Restart.addEventListener("click", restartQuiz)

function restartQuiz(){
  updateResult.innerHTML = "";
 questionPosition = 0;
 outdoorsScore=0;
 indoorsScore=0;
 artScore=0;
 swimmingScore=0;

  document.getElementById("q1a1").disabled = false;
  document.getElementById("q1a2").disabled = false;
  document.getElementById("q1a3").disabled = false;
  document.getElementById("q1a4").disabled = false;
  document.getElementById("q2a1").disabled = false;
  document.getElementById("q2a2").disabled = false;
  document.getElementById("q2a3").disabled = false;
  document.getElementById("q2a4").disabled = false;
  document.getElementById("q3a1").disabled = false;
  document.getElementById("q3a2").disabled = false;
  document.getElementById("q3a3").disabled = false;
  document.getElementById("q3a4").disabled = false;
  document.getElementById("q4a1").disabled = false;
  document.getElementById("q4a2").disabled = false;
  document.getElementById("q4a3").disabled = false;
  document.getElementById("q4a4").disabled = false;
  document.getElementById("q5a1").disabled = false;
  document.getElementById("q5a2").disabled = false;
  document.getElementById("q5a3").disabled = false;
  document.getElementById("q5a4").disabled = false;
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
  }
