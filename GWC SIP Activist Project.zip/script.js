var quoteList = [
 "Half of U.S. adults say they put off or skipped some sort of health care or dental care in the past year because of the cost.", "High health care costs disproportionately affect uninsured adults, Black and Hispanic adults, and those with lower incomes.", "American health care is the most expensive IN THE WORLD, and yet American health is among the worst among rich countries.", "Americans pay almost four times as much for pharmaceutical drugs as citizens of other developed countries."
];

var quote = document.getElementById("quote");
var qBtn = document.getElementById("qBtn");
var count = 0;

// event listener

qBtn.addEventListener("click", displayQuote);

function displayQuote() {
  quote.innerHTML = quoteList[count];
  count++;
  if (count == quoteList.length) {count = 0;}
}
