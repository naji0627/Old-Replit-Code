function noFunction() {
document.getElementById("no1").innerHTML = "Aww.. Okay";
}

function yesFunction() {
document.getElementById("yes").innerHTML = "Great!";
}

function nameFunction() {
  let name = document.getElementById('name').value;
  
document.getElementById("input-name").innerHTML = name;

document.getElementById("Input-name").innerHTML = name;

console.log(name);

}

function newFunction() {
  let x = document.getElementById("name-div");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }

} 

function myFunction() {
  document.getElementById("storyp1").style.display = "block";
}

// story part 2 stuff 


function storyp1() {
  let x = document.getElementById("storyp1");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }

} 

function storyp2c2() {
 let x = document.getElementById("storyp2c2");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}


function p1c1() {
  document.getElementById("storyp2c1").style.display = "block";
}

function p1c2() {
  document.getElementById("storyp2c2").style.display = "block";
}

function continueP3C2() {
   document.getElementById("continue-p3c2").style.display = "block";
}
