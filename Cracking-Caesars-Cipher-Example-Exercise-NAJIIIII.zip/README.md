## Cracking Caesar's Cipher Example Exercise

This is the code that we will use to work through an example to explain the core concept of a for loop. This is **not** related to the project, but we use example exercises to demonstrate how skills are transferable from one context to another. A sandbox of sorts.

### Exercises
- Create a for loop with the range() function to print out each key possibility starting with the key value of 0 and ending with the key value of 93.

---

## File Overview

### ← README.md

README.md file give you more documentation and information about a program. They are super helpful for describing what a program should do, any issues you've encountered, changes you want to make, and more. 

### ← main.py
This is where you will write your main program.