#Use a for loop with the range() function to print out each key possibility starting with the key value of 0 and ending with the key value of 93. 

for key in range(94):
  print(key)