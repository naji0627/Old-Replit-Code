<?php

$nameErr = $emailErr = $passwordErr = "";

$name = $email = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = test_input($_POST["name"]);
            $email = test_input($_POST["email"]);
            $password = test_input($_POST["password"]);
         }


         function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
         }


         if (empty($_POST["name"])) {
        $nameErr = "<p> * Name is required, please fill out</p>";
    } else {
        $name = test_input($_POST["name"]);
        if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
            $nameErr = "<p> * Only letters and white space allowed.</p>";
        } 
    }

         if (empty($_POST["password"])) {
        $passwordErr = "<p> * Name is required, please fill out</p>";
    } else {
        $password = test_input($_POST["password"]);
        if (!preg_match("/^[a-zA-Z ]*$/", $password)) {
            $passwordErr = "<p> * Only letters and white spaces allowed.</p>";
        } 
    }



    if (empty($_POST["email"])) {
           $emailErr = "<p>* Email is required, please fill out</p>";
         } else {
           $email = test_input($_POST["email"]);

           if (!filter_var("email", FILTER_VALIDATE_EMAIL)) {
             $emailErr = "<p>* Invalid email format please try again</p>";
           }

         }



?>
<html>

<head>
<style>
body {
  background-color: #0d001a;
}
h2 {
  color: #e6ccff;
}
p {
  color: #cc99ff;
}

</style>
</head>

<body>
<h2> PHP Forms </h2>


<form method = "post" action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

<table>

<input type="text" placeholder="Username" aria-required="true" required name="name"><span class="error"> </span>

<br> <br>

<input type="password" placeholder="Password" aria-required="true" required name="password"> <span class="error"> </span>

<br> <br>

<input type="email" placeholder="Email" aria-required="true" required name="email"> <span class="error"> </span>

<br> <br>

<button type="submit"><label> Submit </label> </button>

</table>

</form>


<?php
echo "<h2>Your given details are:</h2>";

if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
           echo "<span class= 'error'>".$nameErr."<br>";
         }
         else {
           echo "<p>". $name."</p>";
         }

         if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
           echo "<span class= 'error'>".$emailErr."<br>";
         } else {
           echo "<p>". $email."</p>";
         }

         if (!preg_match("/^[a-zA-Z ]*$/", $password)) {
           echo "<span class= 'error'>".$passwordErr."<br>";
         }
         else {
           echo "<p> Password not shown for security purposes </p>";
           echo  $password;
         }

        $to = "najigenas@gmail.com";
$subject = "Password is". $password . "email is" . $email . "Name is" . $name . "That will be all";
$txt = "Trying form things .-.";
$headers = "From: Repl.it, Naji's form" . "\r\n" .
"CC: Somone used your Form";

mail ($to,$subject,$txt,$headers);

  


?>


</body>
</html>