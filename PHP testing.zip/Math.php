<html>


<head>
<style>
body {
  background-color: #0d001a;
}
p {
  color: #cc99ff;
}
h4 {
  color: #e6ccff;
}
h2 {
  color: #e6ccff;
}
</style>

</head>


<body>

<h2> Math in PHP!! <br>  </h2>
<br> <h4> The first one is a (rand)om function in PHP that picks a random number between the two numbers you put down, like in the example below, 1, 10.
</h4>

<?php

echo "<h4> #1. </h4> <p>".(rand(1,10))."</p> <br>";

echo "<h4> The second uses a function called sqrt that finds the square root of whatever number I plug in, like in this example 16. </h4>";
echo "<h4> #2. </h4> <p>".(sqrt(16))."</p> <br>";


echo "<h4> The Third one rounds any number I plug into a whole number, hense why it's function is called round. the number I used in this example was 2.32 </h4>";
echo "<h4> #3. </h4> <p>".(round(2.32))."</p> <br>";



?>

</body>


</html>