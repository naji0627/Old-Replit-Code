<html>
  <head>
    <title>PHP Testing</title>
<style>

body {
  background-color: #0d001a;
}

h1 {
  color: #e6ccff;
}

#P1 {
      color: #cc99ff;
    }

a:link {
  color: #cc99ff;
}

a:visited {
  color: #cc99ff;
}

a:hover {
  color: salmon;
}

</style>

  </head>
  <body>
  <h1> PHP Testing! </h1>
   <p id="P1"> Tap <a href="PhpForm.php">the link</a> to go to my attempt at making my own form! ^^ </p>
   <br>
   <p id="P1"> Tap <a href="Math.php"> this link </a>  to see some PHP math functions! </p>
   <br>
   <p id="P1"> Tap <a href="WhileLoops.php"> this link </a>  to see the PHP While Loop function! </p>


  </body>
</html>