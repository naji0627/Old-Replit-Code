<html>


<head>
<style>
body {
 background-color: #0d001a;
}
p {
  color: #cc99ff;
}
h4 {
  color: #e6ccff;
}
h2 {
  color: #e6ccff;
}
</style>

</head>


<body>

<h4> While loops tells PHP to execute the nested statement(s) repeatedly, as long as the while expression evaluates to true. And because I set "While ($1 <= 10)" The loop goes on until i equals 10. (The number gets bigger due to the ++ function ex. $i++ )

<?php

$x = 0;
$i = 0;
while ($i <= 10) {
    echo "<p> variable i is equal to ". $i++ ."</p>";
    }
?>


</body>